// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Emerson Lopes and PowerRustCOBOL contributors
//
// Licensed under the Apache License, Version 2.0.
// See the LICENSE file in the project root for full license information.

//! Code generation: converts a [`cobolt_forms::Form`] into a complete COBOL source file.
//!
//! # Architecture (v1.0 — COBOL-85 nested-program model)
//!
//! The `.cfrm` file is the **single source of truth**.  The generated `.cbl` is a
//! build artifact — it is never edited by hand.  Each event handler's full body
//! lives in [`cobolt_forms::EventBinding::code`] (from `ENVIRONMENT DIVISION`
//! through `PROCEDURE DIVISION`), stored in the form file and edited through the
//! modal code editor in the Form Designer.
//!
//! Each event handler becomes a COBOL-85 **nested program** inside the outer program:
//!
//! ```cobol
//!  IDENTIFICATION DIVISION.
//!  PROGRAM-ID. MAIN-FORM.
//!
//!  ENVIRONMENT DIVISION.
//!
//!  DATA DIVISION.
//!  WORKING-STORAGE SECTION.
//!  *>── Form controls ──────────────────────────────────────────
//!  01 WS-BTN-OK.
//!     05 WS-BTN-OK-TEXT    PIC X(256) VALUE "OK".
//!     05 WS-BTN-OK-VISIBLE PIC 9      VALUE 1.
//!     05 WS-BTN-OK-ENABLED PIC 9      VALUE 1.
//!
//!  PROCEDURE DIVISION.
//!  COBOL-MAIN.
//!      CALL "MAIN-FORM--ONLOAD".
//!      PERFORM COBOL-EVENT-LOOP.
//!      CALL "MAIN-FORM--ONCLOSE".
//!      STOP RUN.
//!
//!  COBOL-EVENT-LOOP.
//!      PERFORM UNTIL COBOL-QUIT = 1
//!          CALL "COBOL-WAIT-EVENT"
//!              USING COBOL-EVENT-ID COBOL-CONTROL-ID
//!          EVALUATE COBOL-CONTROL-ID
//!              WHEN "BTN-OK"
//!                  EVALUATE COBOL-EVENT-ID
//!                      WHEN "onClick"
//!                          CALL "BTN-OK--ONCLICK"
//!                  END-EVALUATE
//!          END-EVALUATE
//!      END-PERFORM.
//!
//!  *> ── Nested event-handler programs (COBOL-85) ────────────
//!       IDENTIFICATION DIVISION.
//!       PROGRAM-ID. BTN-OK--ONCLICK.
//!       *>    (full handler body from EventBinding.code goes here:
//!       *>     ENVIRONMENT / DATA / WORKING-STORAGE / LINKAGE /
//!       *>     PROCEDURE DIVISION + statements)
//!           GOBACK.
//!       END PROGRAM BTN-OK--ONCLICK.
//!
//!       END PROGRAM MAIN-FORM.
//! ```

use cobolt_forms::model::PropValue;
use cobolt_forms::{Control, ControlType, Form};

pub mod data_binding;
pub mod indexed;
pub use indexed::{generate_indexed, generate_indexed_fd, generate_indexed_select};

// ── Public API ────────────────────────────────────────────────────────────────

/// Generate a complete COBOL source skeleton from `form`.
///
/// Returns a `String` containing fixed-format COBOL source code.
pub fn generate(form: &Form) -> String {
    let mut out = String::with_capacity(4096);

    write_header(&mut out);
    write_identification(&mut out, form);
    write_environment(&mut out, form);
    write_data_division(&mut out, form);
    write_procedure_division(&mut out, form);

    out
}

/// Regenerate the complete COBOL source from `form`.
///
/// In the v1.0 architecture the `.cbl` is a **build artifact** — all event-handler
/// code is stored in the `.cfrm` file inside [`cobolt_forms::EventBinding`] and
/// edited through the Form Designer's modal code editor.  There is therefore nothing
/// to "merge" from an existing source file; this function is a clean alias for
/// [`generate`].
///
/// The `_existing_source` parameter is accepted for API compatibility but is not
/// read.  Callers that formerly relied on paragraph-preservation behaviour should
/// migrate to storing code in the form model instead.
pub fn regenerate(form: &Form, _existing_source: &str) -> String {
    generate(form)
}

// ── Section writers ───────────────────────────────────────────────────────────

/// Banner comment addressed to the developer, emitted at the very top of every
/// generated source file (GOLDEN RULE). Uses `*>` floating comments so it is
/// ignored by the compiler.
fn write_header(out: &mut String) {
    out.push_str("      *> ───────────────────────────────────────────────────────────\n");
    out.push_str("      *>  This code was generated automatically by PowerRustCOBOL RAD.\n");
    out.push_str("      *>\n");
    out.push_str("      *>  DO NOT MODIFY IT DIRECTLY: it is regenerated the next time\n");
    out.push_str("      *>  you interact with the Form Designer, so manual edits are lost.\n");
    out.push_str("      *>  Edit the form and its event handlers in the Form Designer\n");
    out.push_str("      *>  instead.\n");
    out.push_str("      *>\n");
    out.push_str("      *>  PowerRustCOBOL may change the structure of this generated code\n");
    out.push_str("      *>  at any time — without breaking your code's functionality — for\n");
    out.push_str("      *>  reasons such as performance improvements, new observability\n");
    out.push_str("      *>  features, and bug fixes.\n");
    out.push_str("      *>\n");
    out.push_str("      *>  PowerRustCOBOL and its components are distributed under the\n");
    out.push_str("      *>  Apache 2.0 License.\n");
    out.push_str("      *> ───────────────────────────────────────────────────────────\n");
    out.push('\n');
}

fn write_identification(out: &mut String, form: &Form) {
    out.push_str("       IDENTIFICATION DIVISION.\n");
    out.push_str(&format!("       PROGRAM-ID. {}.\n", form.name));
    out.push('\n');
}

/// Append a fixed section/paragraph header and the developer's verbatim block
/// body, only when the body is non-empty (spec 005 COBOL Structure).
fn weave_block(out: &mut String, header: &str, body: &str) {
    let body = body.trim_end();
    if body.trim().is_empty() {
        return;
    }
    out.push_str(header);
    out.push('\n');
    out.push_str(body);
    // A COBOL paragraph must terminate with a period. If the author didn't write
    // one (e.g. a REPOSITORY whose last `CLASS … IS "…"` entry has no period),
    // supply one right after the last character so the generated code is valid.
    if !body.ends_with('.') {
        out.push('.');
    }
    out.push('\n');
}

fn write_environment(out: &mut String, form: &Form) {
    out.push_str("       ENVIRONMENT DIVISION.\n");

    // ── COBOL Structure: CONFIGURATION / INPUT-OUTPUT (spec 005) ──────────────
    let cs = &form.cobol_structure;
    if !cs.special_names.trim().is_empty() || !cs.repository.trim().is_empty() {
        out.push_str("       CONFIGURATION SECTION.\n");
        weave_block(out, "       SPECIAL-NAMES.", &cs.special_names);
        weave_block(out, "       REPOSITORY.", &cs.repository);
    }
    if !cs.file_control.trim().is_empty() {
        out.push_str("       INPUT-OUTPUT SECTION.\n");
        weave_block(out, "       FILE-CONTROL.", &cs.file_control);
    }
    out.push('\n');
}

fn write_data_division(out: &mut String, form: &Form) {
    out.push_str("       DATA DIVISION.\n");
    // ── COBOL Structure: FILE SECTION (spec 005) — precedes WORKING-STORAGE ───
    weave_block(
        out,
        "       FILE SECTION.",
        &form.cobol_structure.file_section,
    );
    out.push_str("       WORKING-STORAGE SECTION.\n");
    out.push_str("      *>── Cobolt runtime fields ─────────────────────────────────────\n");
    out.push_str("       01 COBOL-QUIT             PIC 9        VALUE 0.\n");
    out.push_str("       01 COBOL-EVENT-ID         PIC X(64)   VALUE SPACES.\n");
    out.push_str("       01 COBOL-CONTROL-ID       PIC X(64)   VALUE SPACES.\n");
    out.push_str("       01 COBOL-LAST-STATUS       PIC X(256)  VALUE SPACES.\n");
    out.push_str("       01 FORM-NAME               PIC X(64)   VALUE ");
    out.push_str(&format!("'{}'.\n", form.name));
    out.push('\n');

    let all_controls = collect_all_controls(&form.controls);

    // Declare the array index var in main WS if any member control has events.
    // The runtime will populate it from the incoming FormEvent's instance_index
    // before the EVALUATE/CALL in the event loop.
    if all_controls
        .iter()
        .any(|c| form.array_binding_context_for_member(&c.id).is_some() && !c.events.is_empty())
    {
        out.push_str("       01 CONTROL-ARRAY-INDEX     PIC S9(4) COMP-5 VALUE 0.\n");
    }

    // ── REST / HTTP infrastructure (emitted when any RestClient exists) ─────
    let has_rest = all_controls
        .iter()
        .any(|c| c.control_type == ControlType::RestClient);
    if has_rest {
        out.push_str("      *>── REST / HTTP runtime variables ──────────────────────────────\n");
        out.push_str("      *>   Usage:\n");
        out.push_str("      *>     MOVE 'https://api.example.com/resource' TO WS-REQUEST-URL\n");
        out.push_str("      *>     PERFORM RST1-GET\n");
        out.push_str("      *>     IF WS-HTTP-STATUS = 200\n");
        out.push_str("      *>         DISPLAY WS-HTTP-RESPONSE\n");
        out.push_str("      *>     END-IF\n");
        out.push_str("       01 WS-REQUEST-URL        PIC X(2048)  VALUE SPACES.\n");
        out.push_str("       01 WS-REQUEST-BODY       PIC X(32767) VALUE SPACES.\n");
        out.push_str("       01 WS-HTTP-RESPONSE      PIC X(32767) VALUE SPACES.\n");
        out.push_str("       01 WS-HTTP-STATUS        PIC 9(4)     VALUE 0.\n");
        out.push_str("       01 WS-HTTP-HEADER-NAME   PIC X(128)   VALUE SPACES.\n");
        out.push_str("       01 WS-HTTP-HEADER-VALUE  PIC X(512)   VALUE SPACES.\n");
        out.push_str("       01 WS-JSON-KEY           PIC X(256)   VALUE SPACES.\n");
        out.push_str("       01 WS-JSON-VALUE         PIC X(4096)  VALUE SPACES.\n");
        out.push('\n');
    }

    // ── Animation runtime fields ───────────────────────────────────────────
    let has_anims =
        all_controls.iter().any(|c| !c.animations.is_empty()) || !form.animations.is_empty();
    if has_anims {
        out.push_str("      *>── Animation runtime fields ──────────────────────────────────\n");
        out.push_str("      *>   INVOKE ctrl-id 'PlayAnimation' USING BY VALUE WS-ANIM-NAME\n");
        out.push_str("       01 WS-ANIM-NAME          PIC X(128)  VALUE SPACES.\n");
        out.push_str("       01 WS-ANIM-ELAPSED-MS    PIC 9(8)    VALUE 0.\n");
        out.push('\n');
    }

    // ── Agent infrastructure ───────────────────────────────────────────────
    let has_agents = all_controls
        .iter()
        .any(|c| c.control_type == ControlType::AgentObject);
    if has_agents {
        out.push_str("      *>── AI Agent infrastructure ────────────────────────────────────\n");
        out.push_str("      *>   INVOKE agent-id 'Ask'\n");
        out.push_str("      *>       USING BY VALUE WS-AGENT-PROMPT\n");
        out.push_str("      *>       RETURNING WS-AGENT-RESPONSE\n");
        out.push_str("       01 WS-AGENT-PROMPT        PIC X(4096)  VALUE SPACES.\n");
        out.push_str("       01 WS-AGENT-RESPONSE      PIC X(32767) VALUE SPACES.\n");
        out.push_str("       01 WS-AGENT-ERROR         PIC X(512)   VALUE SPACES.\n");
        out.push('\n');
    }

    // ── Per-RestClient instance fields ────────────────────────────────────
    for ctrl in all_controls
        .iter()
        .filter(|c| c.control_type == ControlType::RestClient)
    {
        let pfx = format!("WS-{}", ctrl.id.replace('-', "-"));
        let base = ctrl
            .get_prop("BaseURL")
            .map(|v| v.as_str().to_owned())
            .unwrap_or_default();
        out.push_str(&format!(
            "      *>── REST client: {} ──────────────────────────────────\n",
            ctrl.id
        ));
        out.push_str(&format!(
            "       01 {}-BASE-URL      PIC X(2048) VALUE '{}'.\n",
            pfx, base
        ));
        let resp_item = ctrl
            .get_prop("ResponseDataItem")
            .map(|v| v.as_str().to_owned())
            .unwrap_or_default();
        if !resp_item.is_empty() {
            out.push_str(&format!(
                "       01 {}             PIC X(32767) VALUE SPACES.\n",
                resp_item
            ));
        }
        let status_item = ctrl
            .get_prop("StatusDataItem")
            .map(|v| v.as_str().to_owned())
            .unwrap_or_default();
        if !status_item.is_empty() {
            out.push_str(&format!(
                "       01 {}         PIC 9(4) VALUE 0.\n",
                status_item
            ));
        }
        out.push('\n');
    }

    // ── DataGrid CSV fields ───────────────────────────────────────────────
    for ctrl in all_controls
        .iter()
        .filter(|c| c.control_type == ControlType::DataGrid)
    {
        if datagrid_csv_export_enabled(ctrl) {
            let pfx = format!("WS-{}", ctrl.id.replace('-', "-"));
            out.push_str(&format!(
                "      *>── DataGrid {} CSV export ──────────────────────────\n",
                ctrl.id
            ));
            out.push_str(&format!(
                "       01 {}-CSV-PATH    PIC X(512)  VALUE SPACES.\n",
                pfx
            ));
            out.push_str(&format!(
                "       01 {}-CSV-STATUS  PIC 9       VALUE 0.\n",
                pfx
            ));
            out.push('\n');
        }
    }

    // ── SQL Database infrastructure (Phase 8) ────────────────────────────
    let has_sql = all_controls
        .iter()
        .any(|c| c.control_type == ControlType::SqlDatabase);
    if has_sql {
        out.push_str("      *>── SQL Database runtime variables ──────────────────────────────\n");
        out.push_str("      *>   Usage:\n");
        out.push_str("      *>     MOVE 'SELECT * FROM t' TO WS-SQL-QUERY\n");
        out.push_str("      *>     PERFORM DB1-CONNECT\n");
        out.push_str("      *>     PERFORM DB1-EXEC\n");
        out.push_str("      *>     PERFORM UNTIL WS-SQL-MORE = 'N'\n");
        out.push_str("      *>         MOVE 1 TO WS-SQL-COL-INDEX\n");
        out.push_str("      *>         CALL \"COBOL-FETCH-ROW\" USING WS-DB1-HANDLE\n");
        out.push_str("      *>                                       WS-SQL-COL-INDEX\n");
        out.push_str("      *>                                       WS-SQL-CURRENT-VALUE\n");
        out.push_str("      *>                                       WS-SQL-ERROR\n");
        out.push_str("      *>         CALL \"COBOL-NEXT-ROW\" USING WS-DB1-HANDLE\n");
        out.push_str("      *>                                      WS-SQL-MORE\n");
        out.push_str("      *>     END-PERFORM\n");
        out.push_str("       01 WS-SQL-QUERY           PIC X(4096)  VALUE SPACES.\n");
        out.push_str("       01 WS-SQL-ERROR            PIC X(512)   VALUE SPACES.\n");
        out.push_str("       01 WS-SQL-ROW-COUNT        PIC 9(9)     VALUE 0.\n");
        out.push_str("       01 WS-SQL-COL-INDEX        PIC 9(4)     VALUE 1.\n");
        out.push_str("       01 WS-SQL-CURRENT-VALUE    PIC X(512)   VALUE SPACES.\n");
        out.push_str("       01 WS-SQL-MORE             PIC X(1)     VALUE 'N'.\n");
        out.push('\n');
    }

    for ctrl in all_controls
        .iter()
        .filter(|c| c.control_type == ControlType::SqlDatabase)
    {
        let pfx = format!("WS-{}", ctrl.id.to_ascii_uppercase());
        let cs = ctrl
            .get_prop("ConnectionString")
            .map(|v| v.as_str().to_owned())
            .unwrap_or_else(|| ":memory:".into());
        let drv = ctrl
            .get_prop("Driver")
            .map(|v| v.as_str().to_owned())
            .unwrap_or_else(|| "sqlite".into());
        out.push_str(&format!(
            "      *>── SQL instance: {} ({}) ─────────────────────────────────\n",
            ctrl.id, drv
        ));
        out.push_str(&format!(
            "       01 {pfx}-CONN-STRING   PIC X(512)  VALUE '{cs}'.\n"
        ));
        out.push_str(&format!(
            "       01 {pfx}-HANDLE        PIC 9(9)    VALUE 0.\n"
        ));
        out.push_str(&format!(
            "       01 {pfx}-STATUS        PIC X(512)  VALUE SPACES.\n"
        ));
        out.push('\n');
    }

    // ── Timer runtime fields ──────────────────────────────────────────────
    for ctrl in all_controls
        .iter()
        .filter(|c| c.control_type == ControlType::Timer)
    {
        let pfx = format!("WS-{}", ctrl.id.replace('-', "-"));
        let iv = ctrl
            .get_prop("Interval")
            .map(|v| v.as_i64())
            .unwrap_or(1000);
        let ena = ctrl
            .get_prop("Enabled")
            .map(|v| if v.as_bool() { 1 } else { 0 })
            .unwrap_or(1);
        out.push_str(&format!(
            "      *>── Timer: {} ──────────────────────────────────────────\n",
            ctrl.id
        ));
        out.push_str(&format!(
            "       01 {}-INTERVAL   PIC 9(8) VALUE {}.\n",
            pfx, iv
        ));
        out.push_str(&format!(
            "       01 {}-ENABLED    PIC 9    VALUE {}.\n",
            pfx, ena
        ));
        out.push_str(&format!("       01 {}-ELAPSED-MS PIC 9(8) VALUE 0.\n", pfx));
        out.push('\n');
    }

    // ── Chart working-storage items ───────────────────────────────────────
    let chart_types = [
        ControlType::BarChart,
        ControlType::LineChart,
        ControlType::PieChart,
        ControlType::AreaChart,
        ControlType::ScatterChart,
        ControlType::DonutChart,
    ];
    for ctrl in all_controls
        .iter()
        .filter(|c| chart_types.contains(&c.control_type))
    {
        let pfx = format!("WS-{}", ctrl.id.to_ascii_uppercase().replace('-', "-"));
        let ds = ctrl
            .get_prop("DataSource")
            .map(|v| v.as_str().to_owned())
            .unwrap_or_default();
        let cnt = ctrl
            .get_prop("DataCount")
            .map(|v| v.as_str().to_owned())
            .unwrap_or_default();
        let kind = ctrl.control_type.as_str();
        out.push_str(&format!(
            "      *>── Chart: {} (type: {}) ─────────────────────────────────────\n",
            ctrl.id, kind
        ));
        out.push_str(&format!(
            "      *>   Data source : {}\n",
            if ds.is_empty() {
                "(none — use INVOKE SET-TABLE or ADD-POINT)"
            } else {
                &ds
            }
        ));
        out.push_str(&format!(
            "      *>   Row count   : {}\n",
            if cnt.is_empty() { "(not set)" } else { &cnt }
        ));
        out.push_str(&format!(
            "       01 {}-SELECTED-IDX PIC 9(6) VALUE 0.\n",
            pfx
        ));
        out.push_str(&format!(
            "       01 {}-SELECTED-LBL PIC X(64) VALUE SPACES.\n",
            pfx
        ));
        out.push_str(&format!(
            "       01 {}-SELECTED-VAL PIC 9(18)V9(6) VALUE ZEROES.\n",
            pfx
        ));
        out.push('\n');
    }

    // ── User Working Storage (raw COBOL from .cfrm) ──────────────────────
    // Preserve each line's own COBOL indentation: only drop leading/trailing
    // blank lines (a blanket `.trim()` would strip the first item's area-A/B
    // columns and break a fixed-format build).
    if !form.user_ws_source.trim().is_empty() {
        out.push_str("      *>── User Working Storage ────────────────────────────────────────\n");
        let mut started = false;
        for line in form.user_ws_source.trim_end().lines() {
            if !started && line.trim().is_empty() {
                continue;
            }
            started = true;
            out.push_str(line);
            out.push('\n');
        }
        out.push('\n');
    }

    data_binding::write_data_binding_storage(out, form);

    // ── Per-control groups ────────────────────────────────────────────────
    if !all_controls.is_empty() {
        out.push_str("      *>── Form controls ───────────────────────────────────────────────\n");
        for ctrl in &all_controls {
            write_control_group(out, ctrl);
        }
    }
}

/// Write a `01 WS-<ID>.` group for one control.
fn write_control_group(out: &mut String, ctrl: &Control) {
    let prefix = format!("WS-{}", ctrl.id.replace('-', "-"));
    out.push_str(&format!("       01 {}.\n", prefix));

    // Caption / Text property (if present)
    let caption_key = caption_prop_key(&ctrl.control_type);
    let caption_val = ctrl
        .get_prop(caption_key)
        .map(|v| match v {
            PropValue::String(s) => s.clone(),
            PropValue::Int(n) => n.to_string(),
            PropValue::Bool(b) => if *b { "1" } else { "0" }.to_string(),
        })
        .unwrap_or_else(|| ctrl.id.clone());

    out.push_str(&format!(
        "          05 {}-TEXT       PIC X(256) VALUE '{}'.\n",
        prefix, caption_val
    ));
    out.push_str(&format!(
        "          05 {}-VISIBLE    PIC 9      VALUE {}.\n",
        prefix,
        if ctrl.visible { 1 } else { 0 }
    ));
    out.push_str(&format!(
        "          05 {}-ENABLED    PIC 9      VALUE {}.\n",
        prefix,
        if ctrl.enabled { 1 } else { 0 }
    ));

    // Extra numeric value field for editable controls
    if matches!(
        ctrl.control_type,
        ControlType::TextBox | ControlType::CheckBox | ControlType::ComboBox | ControlType::ListBox
    ) {
        out.push_str(&format!(
            "          05 {}-VALUE      PIC X(512) VALUE SPACES.\n",
            prefix
        ));
    }

    // Slider: numeric value + min/max/step fields
    if matches!(ctrl.control_type, ControlType::Slider) {
        let val = ctrl.get_prop("Value").map(|v| v.as_i64()).unwrap_or(0);
        let min = ctrl.get_prop("Minimum").map(|v| v.as_i64()).unwrap_or(0);
        let max = ctrl.get_prop("Maximum").map(|v| v.as_i64()).unwrap_or(100);
        let step = ctrl.get_prop("Step").map(|v| v.as_i64()).unwrap_or(10);
        // Each 05 item must start at column 8+ in fixed-format COBOL.
        // Use separate push_str calls so Rust string continuation (`\n\`)
        // does not eat the leading spaces that position the level numbers.
        out.push_str(&format!(
            "          05 {prefix}-VALUE      PIC S9(9) VALUE {val}.\n"
        ));
        out.push_str(&format!(
            "          05 {prefix}-MINIMUM    PIC S9(9) VALUE {min}.\n"
        ));
        out.push_str(&format!(
            "          05 {prefix}-MAXIMUM    PIC S9(9) VALUE {max}.\n"
        ));
        out.push_str(&format!(
            "          05 {prefix}-STEP       PIC S9(9) VALUE {step}.\n"
        ));
    }

    out.push('\n');
}

fn write_procedure_division(out: &mut String, form: &Form) {
    out.push_str("       PROCEDURE DIVISION.\n");

    let all_controls = collect_all_controls(&form.controls);

    // ── COBOL-MAIN ──────────────────────────────────────────────────────
    out.push_str("       COBOL-MAIN.\n");
    out.push_str("           CALL \"COBOL-INIT-FORM\" USING FORM-NAME\n");
    if !form.data_bindings.is_empty() {
        out.push_str("           PERFORM COBOL-DATA-BINDINGS-LOAD\n");
    }

    // Kick off timer dispatcher if any timers exist
    let has_timers = all_controls
        .iter()
        .any(|c| c.control_type == ControlType::Timer);
    if has_timers {
        out.push_str("           PERFORM COBOL-START-TIMERS\n");
    }

    for ctrl in all_controls
        .iter()
        .filter(|c| c.control_type == ControlType::IndexedFile && prop_bool(c, "AutoOpen", false))
    {
        out.push_str(&format!("           PERFORM {}-OPEN\n", ctrl.id));
    }

    // Call OnLoad nested program
    if let Some(ev) = form.form_events.iter().find(|e| e.event == "onLoad") {
        out.push_str(&format!("           CALL \"{}\"\n", ev.paragraph));
    }

    if !form.data_bindings.is_empty() {
        out.push_str("           PERFORM COBOL-DATA-BINDINGS-POPULATE\n");
        out.push_str("           PERFORM COBOL-DATA-BINDINGS-MARK-CLEAN\n");
    }

    out.push_str("           PERFORM COBOL-EVENT-LOOP\n");

    // Call OnClose nested program
    if let Some(ev) = form.form_events.iter().find(|e| e.event == "onClose") {
        out.push_str(&format!("           CALL \"{}\"\n", ev.paragraph));
    }

    for ctrl in all_controls
        .iter()
        .filter(|c| c.control_type == ControlType::IndexedFile && prop_bool(c, "AutoOpen", false))
    {
        out.push_str(&format!("           PERFORM {}-CLOSE\n", ctrl.id));
    }

    out.push_str("           STOP RUN.\n");
    out.push('\n');

    // ── COBOL-EVENT-LOOP — dispatches via CALL to nested programs ─────────
    write_event_loop(out, form);

    // ── Infrastructure helper paragraphs (outer program scope) ────────────
    write_timer_stubs(out, &all_controls);
    write_csv_export_stubs(out, &all_controls);
    write_rest_client_stubs(out, &all_controls);
    write_sql_stubs(out, &all_controls);
    write_indexed_file_stubs(out, &all_controls);
    write_agent_stubs(out, &all_controls);
    write_animation_stubs(out, form, &all_controls);
    write_chart_stubs(out, &all_controls);
    data_binding::write_data_binding_paragraphs(out, form);

    // ── Nested COBOL-85 programs — one per event handler ─────────────────
    write_nested_programs(out, form, &all_controls);

    // ── Close the outer program ───────────────────────────────────────────
    out.push_str(&format!("       END PROGRAM {}.\n", form.name));
}

// ── Timer paragraph generator ─────────────────────────────────────────────────

fn write_timer_stubs(out: &mut String, all_controls: &[&Control]) {
    let timers: Vec<&&Control> = all_controls
        .iter()
        .filter(|c| c.control_type == ControlType::Timer)
        .collect();
    if timers.is_empty() {
        return;
    }

    // COBOL-START-TIMERS: enable each timer at startup
    out.push_str("       COBOL-START-TIMERS.\n");
    out.push_str("      *>    Called once from COBOL-MAIN to register timer intervals.\n");
    for ctrl in &timers {
        let iv = ctrl
            .get_prop("Interval")
            .map(|v| v.as_i64())
            .unwrap_or(1000);
        out.push_str(&format!(
            "           INVOKE {id} 'SetInterval' USING BY VALUE {iv}\n",
            id = ctrl.id,
            iv = iv
        ));
    }
    out.push_str("           CONTINUE.\n");
    out.push('\n');

    // Timer ticks are EVENTS in the nested-program model: the runtime fires
    // an `onTick` form event per interval, and the standard COBOL-EVENT-LOOP
    // dispatches it via CALL to the timer's `TIMER-ID--ONTICK` nested program
    // (bind the handler in the designer's Events list). No paragraph-based
    // tick dispatcher is generated.
}

// ── DataGrid CSV export paragraph generator ───────────────────────────────────

fn write_csv_export_stubs(out: &mut String, all_controls: &[&Control]) {
    for ctrl in all_controls
        .iter()
        .filter(|c| c.control_type == ControlType::DataGrid)
    {
        if !ctrl
            .get_prop("ShowCSVExportButton")
            .map(|v| v.as_bool())
            .unwrap_or_else(|| datagrid_csv_export_enabled(ctrl))
        {
            continue;
        }
        let pfx = format!("WS-{}", ctrl.id.replace('-', "-"));
        let para = ctrl
            .get_prop("CSVParagraph")
            .map(|v| v.as_str().to_owned())
            .unwrap_or_else(|| format!("{}-EXPORT-CSV", ctrl.id));
        let delim = ctrl
            .get_prop("CSVDelimiter")
            .map(|v| v.as_str().to_owned())
            .unwrap_or_else(|| ",".to_owned());
        let mode = ctrl
            .get_prop("CSVExportMode")
            .map(|v| v.as_str().to_owned())
            .unwrap_or_else(|| "Filtered".to_owned());

        out.push_str(&format!("       {}.\n", para));
        out.push_str(&format!(
            "      *>    Export {} data to CSV file.  Delimiter: \"{}\". Mode: {}.\n",
            ctrl.id, delim, mode
        ));
        out.push_str(
            "      *>    Column order and filtered/all rows follow the DataGrid settings.\n",
        );
        out.push_str(&format!(
            "      *>    Set {pfx}-CSV-PATH to the desired output file path before calling.\n"
        ));
        out.push_str(&format!(
            "           INVOKE {id} 'ExportCSV'\n",
            id = ctrl.id
        ));
        out.push_str(&format!(
            "               USING BY REFERENCE {pfx}-CSV-PATH\n"
        ));
        out.push_str(&format!("               RETURNING {pfx}-CSV-STATUS\n"));
        out.push_str(&format!("           IF {pfx}-CSV-STATUS NOT = 0\n"));
        out.push_str(&format!(
            "               DISPLAY \"CSV export error: \" {pfx}-CSV-STATUS\n"
        ));
        out.push_str("           END-IF.\n");
        out.push('\n');
    }
}

fn datagrid_csv_export_enabled(ctrl: &Control) -> bool {
    ctrl.get_prop("ExportCSV")
        .map(|v| v.as_bool())
        .unwrap_or(false)
        || ctrl
            .get_prop("ShowCSVExportButton")
            .map(|v| v.as_bool())
            .unwrap_or(false)
}

// ── RestClient call stub generator ───────────────────────────────────────────

fn write_rest_client_stubs(out: &mut String, all_controls: &[&Control]) {
    for ctrl in all_controls
        .iter()
        .filter(|c| c.control_type == ControlType::RestClient)
    {
        let para_get = format!("{}-GET", ctrl.id);
        let para_post = format!("{}-POST", ctrl.id);
        let para_put = format!("{}-PUT", ctrl.id);
        let resp_para = ctrl
            .get_prop("ResponseParagraph")
            .map(|v| v.as_str().to_owned())
            .unwrap_or_else(|| format!("{}-ON-RESPONSE", ctrl.id));
        let err_para = ctrl
            .get_prop("ErrorParagraph")
            .map(|v| v.as_str().to_owned())
            .unwrap_or_else(|| format!("{}-ON-ERROR", ctrl.id));
        let resp_item = ctrl
            .get_prop("ResponseDataItem")
            .map(|v| v.as_str().to_owned())
            .unwrap_or_default();
        let status_item = ctrl
            .get_prop("StatusDataItem")
            .map(|v| v.as_str().to_owned())
            .unwrap_or_default();

        // ── {ID}-GET ─────────────────────────────────────────────────────────
        out.push_str(&format!("       {}.\n", para_get));
        out.push_str(&format!(
            "      *>    HTTP GET via {} — set WS-REQUEST-URL before calling.\n",
            ctrl.id
        ));
        out.push_str("           CALL \"COBOL-HTTP-GET\"\n");
        out.push_str("               USING WS-REQUEST-URL\n");
        out.push_str("                     WS-HTTP-RESPONSE\n");
        out.push_str("                     WS-HTTP-STATUS\n");
        out.push_str("           END-CALL\n");
        out.push_str("           EVALUATE TRUE\n");
        out.push_str("               WHEN WS-HTTP-STATUS >= 200\n");
        out.push_str("                AND WS-HTTP-STATUS <= 299\n");
        out.push_str(&format!("                   PERFORM {}\n", resp_para));
        out.push_str("               WHEN OTHER\n");
        out.push_str(&format!("                   PERFORM {}\n", err_para));
        out.push_str("           END-EVALUATE.\n");
        out.push('\n');

        // ── {ID}-POST ────────────────────────────────────────────────────────
        out.push_str(&format!("       {}.\n", para_post));
        out.push_str(&format!(
            "      *>    HTTP POST via {} — set WS-REQUEST-URL and WS-REQUEST-BODY before calling.\n",
            ctrl.id
        ));
        out.push_str("           CALL \"COBOL-HTTP-POST\"\n");
        out.push_str("               USING WS-REQUEST-URL\n");
        out.push_str("                     WS-REQUEST-BODY\n");
        out.push_str("                     WS-HTTP-RESPONSE\n");
        out.push_str("                     WS-HTTP-STATUS\n");
        out.push_str("           END-CALL\n");
        out.push_str("           EVALUATE TRUE\n");
        out.push_str("               WHEN WS-HTTP-STATUS >= 200\n");
        out.push_str("                AND WS-HTTP-STATUS <= 299\n");
        out.push_str(&format!("                   PERFORM {}\n", resp_para));
        out.push_str("               WHEN OTHER\n");
        out.push_str(&format!("                   PERFORM {}\n", err_para));
        out.push_str("           END-EVALUATE.\n");
        out.push('\n');

        // ── {ID}-PUT ─────────────────────────────────────────────────────────
        out.push_str(&format!("       {}.\n", para_put));
        out.push_str(&format!(
            "      *>    HTTP PUT via {} — set WS-REQUEST-URL and WS-REQUEST-BODY before calling.\n",
            ctrl.id
        ));
        out.push_str("           CALL \"COBOL-HTTP-PUT\"\n");
        out.push_str("               USING WS-REQUEST-URL\n");
        out.push_str("                     WS-REQUEST-BODY\n");
        out.push_str("                     WS-HTTP-RESPONSE\n");
        out.push_str("                     WS-HTTP-STATUS\n");
        out.push_str("           END-CALL\n");
        out.push_str("           EVALUATE TRUE\n");
        out.push_str("               WHEN WS-HTTP-STATUS >= 200\n");
        out.push_str("                AND WS-HTTP-STATUS <= 299\n");
        out.push_str(&format!("                   PERFORM {}\n", resp_para));
        out.push_str("               WHEN OTHER\n");
        out.push_str(&format!("                   PERFORM {}\n", err_para));
        out.push_str("           END-EVALUATE.\n");
        out.push('\n');

        // ── Response / error handler stubs ───────────────────────────────────
        write_stub_paragraph(
            out,
            &resp_para,
            &format!(
                "{} response handler — WS-HTTP-RESPONSE contains the body, WS-HTTP-STATUS the code",
                ctrl.id
            ),
        );
        write_stub_paragraph(
            out,
            &err_para,
            &format!(
                "{} error handler — WS-HTTP-STATUS contains the error code (0 = network failure)",
                ctrl.id
            ),
        );

        // ── Optional sync paragraph ───────────────────────────────────────────
        if !resp_item.is_empty() || !status_item.is_empty() {
            let sync_para = format!("{}-SYNC-ITEMS", ctrl.id);
            out.push_str(&format!("       {}.\n", sync_para));
            out.push_str("      *>    Copy response / status into your declared data items.\n");
            if !resp_item.is_empty() {
                out.push_str(&format!(
                    "           MOVE WS-HTTP-RESPONSE TO {}\n",
                    resp_item
                ));
            }
            if !status_item.is_empty() {
                out.push_str(&format!(
                    "           MOVE WS-HTTP-STATUS TO {}\n",
                    status_item
                ));
            }
            out.push_str("           CONTINUE.\n");
            out.push('\n');
        }
    }
}

// ── AgentObject Ask stub generator ───────────────────────────────────────────

fn write_agent_stubs(out: &mut String, all_controls: &[&Control]) {
    for ctrl in all_controls
        .iter()
        .filter(|c| c.control_type == ControlType::AgentObject)
    {
        let ask_para = format!("{}-ASK", ctrl.id);
        let resp_para = ctrl
            .get_prop("ResponseParagraph")
            .map(|v| v.as_str().to_owned())
            .unwrap_or_else(|| format!("{}-ON-RESPONSE", ctrl.id));
        let err_para = ctrl
            .get_prop("ErrorParagraph")
            .map(|v| v.as_str().to_owned())
            .unwrap_or_else(|| format!("{}-ON-ERROR", ctrl.id));
        let resp_item = ctrl
            .get_prop("ResponseDataItem")
            .map(|v| v.as_str().to_owned())
            .unwrap_or_default();
        let model = ctrl
            .get_prop("AgentModel")
            .map(|v| v.as_str().to_owned())
            .unwrap_or_else(|| "llama3.2".into());
        let url = ctrl
            .get_prop("AgentURL")
            .map(|v| v.as_str().to_owned())
            .unwrap_or_else(|| "http://localhost:11434".into());

        out.push_str(&format!("       {}.\n", ask_para));
        out.push_str(&format!(
            "      *>    Ask the AI agent {} (model: {}, endpoint: {})\n",
            ctrl.id, model, url
        ));
        out.push_str("      *>    Set WS-AGENT-PROMPT before calling.\n");
        out.push_str(&format!(
            "           INVOKE {id} 'Ask'\n               USING BY VALUE WS-AGENT-PROMPT\n               RETURNING WS-AGENT-RESPONSE\n",
            id = ctrl.id
        ));
        if !resp_item.is_empty() {
            out.push_str(&format!(
                "           MOVE WS-AGENT-RESPONSE TO {}\n",
                resp_item
            ));
        }
        out.push_str("           EVALUATE TRUE\n");
        out.push_str("               WHEN WS-AGENT-ERROR = SPACES\n");
        out.push_str(&format!("                   PERFORM {}\n", resp_para));
        out.push_str("               WHEN OTHER\n");
        out.push_str(&format!("                   PERFORM {}\n", err_para));
        out.push_str("           END-EVALUATE.\n");
        out.push('\n');

        write_stub_paragraph(
            out,
            &resp_para,
            &format!(
                "{} response ready — WS-AGENT-RESPONSE contains the LLM reply",
                ctrl.id
            ),
        );
        write_stub_paragraph(
            out,
            &err_para,
            &format!(
                "{} error handler — WS-AGENT-ERROR contains the error message",
                ctrl.id
            ),
        );
    }
}

// ── Animation play / stop stub generator ─────────────────────────────────────

fn write_animation_stubs(out: &mut String, form: &Form, all_controls: &[&Control]) {
    // Gather every named animation across all controls + form itself
    let mut entries: Vec<(String, String)> = Vec::new(); // (ctrl_id, anim_name)
    for anim in &form.animations {
        entries.push(("FORM".into(), anim.name.clone()));
    }
    for ctrl in all_controls {
        for anim in &ctrl.animations {
            entries.push((ctrl.id.clone(), anim.name.clone()));
        }
    }
    if entries.is_empty() {
        return;
    }

    // ── COBOL-PLAY-ANIMATION ─────────────────────────────────────────────────
    // Dispatches to the correct INVOKE based on WS-ANIM-NAME.
    out.push_str("       COBOL-PLAY-ANIMATION.\n");
    out.push_str("      *> Set WS-ANIM-NAME before calling this paragraph.\n");
    if entries.len() == 1 {
        let (ctrl_id, anim_name) = &entries[0];
        if ctrl_id != "FORM" {
            out.push_str(&format!("           INVOKE {ctrl_id} 'PlayAnimation'\n"));
            out.push_str(&format!("               USING BY VALUE \"{anim_name}\".\n"));
        } else {
            out.push_str("           CONTINUE.\n");
        }
    } else {
        out.push_str("           EVALUATE WS-ANIM-NAME\n");
        for (ctrl_id, anim_name) in &entries {
            out.push_str(&format!("               WHEN \"{anim_name}\"\n"));
            if ctrl_id != "FORM" {
                out.push_str(&format!(
                    "                   INVOKE {ctrl_id} 'PlayAnimation'\n"
                ));
                out.push_str(&format!(
                    "                       USING BY VALUE \"{anim_name}\"\n"
                ));
            } else {
                out.push_str("                   CONTINUE\n");
            }
        }
        out.push_str("               WHEN OTHER\n");
        out.push_str("                   CONTINUE\n");
        out.push_str("           END-EVALUATE.\n");
    }
    out.push('\n');

    // ── COBOL-STOP-ANIMATION ──────────────────────────────────────────────────
    out.push_str("       COBOL-STOP-ANIMATION.\n");
    out.push_str("      *> Set WS-ANIM-NAME before calling this paragraph.\n");
    if entries.len() == 1 {
        let (ctrl_id, anim_name) = &entries[0];
        if ctrl_id != "FORM" {
            out.push_str(&format!("           INVOKE {ctrl_id} 'StopAnimation'\n"));
            out.push_str(&format!("               USING BY VALUE \"{anim_name}\".\n"));
        } else {
            out.push_str("           CONTINUE.\n");
        }
    } else {
        out.push_str("           EVALUATE WS-ANIM-NAME\n");
        for (ctrl_id, anim_name) in &entries {
            out.push_str(&format!("               WHEN \"{anim_name}\"\n"));
            if ctrl_id != "FORM" {
                out.push_str(&format!(
                    "                   INVOKE {ctrl_id} 'StopAnimation'\n"
                ));
                out.push_str(&format!(
                    "                       USING BY VALUE \"{anim_name}\"\n"
                ));
            } else {
                out.push_str("                   CONTINUE\n");
            }
        }
        out.push_str("               WHEN OTHER\n");
        out.push_str("                   CONTINUE\n");
        out.push_str("           END-EVALUATE.\n");
    }
    out.push('\n');

    // ── Per-trigger auto-call paragraphs ──────────────────────────────────────
    // Emit OnLoad / OnClick / OnFocus trigger helpers for each control's anims.
    for ctrl in all_controls {
        for anim in &ctrl.animations {
            if anim.trigger.as_str() == "OnLoad" {
                // already called from COBOL-FORM-LOAD via timer dispatch
                continue;
            }
            let para = format!(
                "{}-PLAY-{}",
                ctrl.id,
                anim.name
                    .to_ascii_uppercase()
                    .replace(' ', "-")
                    .replace('-', "-")
            );
            out.push_str(&format!("       {para}.\n"));
            out.push_str(&format!("           INVOKE {} 'PlayAnimation'\n", ctrl.id));
            out.push_str(&format!(
                "               USING BY VALUE \"{}\".\n\n",
                anim.name
            ));
        }
    }
}

// ── SqlDatabase stub generator (Phase 8) ─────────────────────────────────────
//
// Generates ready-to-run COBOL paragraphs that use the COBOL-OPEN-DB,
// COBOL-EXEC-SQL, COBOL-FETCH-ROW, COBOL-NEXT-ROW, and COBOL-CLOSE-DB
// built-in CALLs provided by the cobolt-runtime database engine.

fn write_sql_stubs(out: &mut String, all_controls: &[&Control]) {
    for ctrl in all_controls
        .iter()
        .filter(|c| c.control_type == ControlType::SqlDatabase)
    {
        let id = ctrl.id.as_str();
        let pfx = format!("WS-{}", id.to_ascii_uppercase());
        // Backend label derived from the Driver property (sqlite / postgres /
        // mysql). The runtime actually routes on the connection-string scheme,
        // so this only affects the generated comments.
        let drv = ctrl
            .get_prop("Driver")
            .map(|v| v.as_str().to_owned())
            .unwrap_or_else(|| "sqlite".into());
        let drv_label = match drv.to_ascii_lowercase().as_str() {
            "postgres" | "postgresql" => "PostgreSQL",
            "mysql" => "MySQL",
            _ => "SQLite",
        };

        let conn_para = format!("{id}-CONNECT");
        let exec_para = format!("{id}-EXEC");
        let fetch_para = format!("{id}-FETCH-ALL");
        let close_para = format!("{id}-CLOSE");

        let connect_ok = ctrl
            .get_prop("ConnectParagraph")
            .map(|v| v.as_str().to_owned())
            .filter(|s| !s.is_empty())
            .unwrap_or_else(|| format!("{id}-ON-CONNECT"));
        let query_done = ctrl
            .get_prop("QueryCompleteParagraph")
            .map(|v| v.as_str().to_owned())
            .filter(|s| !s.is_empty())
            .unwrap_or_else(|| format!("{id}-ON-QUERY-DONE"));
        let error_para = ctrl
            .get_prop("ErrorParagraph")
            .map(|v| v.as_str().to_owned())
            .filter(|s| !s.is_empty())
            .unwrap_or_else(|| format!("{id}-ON-ERROR"));

        // ── {id}-CONNECT ───────────────────────────────────────────────────
        // Opens a SQLite connection using the connection string in
        // {pfx}-CONN-STRING.  Stores the handle in {pfx}-HANDLE.
        out.push_str(&format!("       {conn_para}.\n"));
        out.push_str(&format!(
            "      *>  Open a {drv_label} connection for {id}.\n"
        ));
        out.push_str(&format!(
            "      *>  Connection string is in {pfx}-CONN-STRING.\n"
        ));
        out.push_str(&format!(
            "      *>  On success: {pfx}-HANDLE holds the connection handle.\n"
        ));
        out.push_str(&format!(
            "      *>  On error:   WS-SQL-ERROR contains the message.\n"
        ));
        out.push_str(&format!("           MOVE SPACES TO WS-SQL-ERROR\n"));
        out.push_str(&format!("           CALL \"COBOL-OPEN-DB\"\n"));
        out.push_str(&format!(
            "               USING BY REFERENCE {pfx}-CONN-STRING\n"
        ));
        out.push_str(&format!("                     BY REFERENCE {pfx}-HANDLE\n"));
        out.push_str(&format!("                     BY REFERENCE WS-SQL-ERROR\n"));
        out.push_str(&format!("           IF WS-SQL-ERROR NOT = SPACES\n"));
        out.push_str(&format!("               PERFORM {error_para}\n"));
        out.push_str(&format!("           ELSE\n"));
        out.push_str(&format!("               PERFORM {connect_ok}\n"));
        out.push_str(&format!("           END-IF.\n"));
        out.push('\n');

        // ── {id}-EXEC ──────────────────────────────────────────────────────
        // Executes the SQL in WS-SQL-QUERY.
        // Row count / affected rows → WS-SQL-ROW-COUNT.
        out.push_str(&format!("       {exec_para}.\n"));
        out.push_str(&format!("      *>  Execute WS-SQL-QUERY via {id}.\n"));
        out.push_str(&format!(
            "      *>  Stores row count in WS-SQL-ROW-COUNT.\n"
        ));
        out.push_str(&format!(
            "      *>  Resets WS-SQL-MORE to 'Y' if rows are present.\n"
        ));
        out.push_str(&format!("           MOVE SPACES TO WS-SQL-ERROR\n"));
        out.push_str(&format!("           CALL \"COBOL-EXEC-SQL\"\n"));
        out.push_str(&format!("               USING BY REFERENCE {pfx}-HANDLE\n"));
        out.push_str(&format!("                     BY REFERENCE WS-SQL-QUERY\n"));
        out.push_str(&format!(
            "                     BY REFERENCE WS-SQL-ROW-COUNT\n"
        ));
        out.push_str(&format!("                     BY REFERENCE WS-SQL-ERROR\n"));
        out.push_str(&format!("           IF WS-SQL-ERROR NOT = SPACES\n"));
        out.push_str(&format!("               PERFORM {error_para}\n"));
        out.push_str(&format!("           ELSE\n"));
        out.push_str(&format!("               IF WS-SQL-ROW-COUNT > 0\n"));
        out.push_str(&format!("                   MOVE 'Y' TO WS-SQL-MORE\n"));
        out.push_str(&format!("               ELSE\n"));
        out.push_str(&format!("                   MOVE 'N' TO WS-SQL-MORE\n"));
        out.push_str(&format!("               END-IF\n"));
        out.push_str(&format!("               PERFORM {query_done}\n"));
        out.push_str(&format!("           END-IF.\n"));
        out.push('\n');

        // ── {id}-FETCH-ALL ─────────────────────────────────────────────────
        // Template loop — user copies this and adds their own MOVE/COMPUTE
        // statements to read column values from WS-SQL-CURRENT-VALUE.
        out.push_str(&format!("       {fetch_para}.\n"));
        out.push_str(&format!(
            "      *>  Iterate over all rows returned by {id}-EXEC.\n"
        ));
        out.push_str(&format!(
            "      *>  Copy this paragraph and add column reads inside the loop.\n"
        ));
        out.push_str(&format!("      *>  Example:\n"));
        out.push_str(&format!("      *>    MOVE 1 TO WS-SQL-COL-INDEX\n"));
        out.push_str(&format!(
            "      *>    CALL \"COBOL-FETCH-ROW\" USING {pfx}-HANDLE\n"
        ));
        out.push_str(&format!(
            "      *>                                   WS-SQL-COL-INDEX\n"
        ));
        out.push_str(&format!(
            "      *>                                   WS-SQL-CURRENT-VALUE\n"
        ));
        out.push_str(&format!(
            "      *>                                   WS-SQL-ERROR\n"
        ));
        out.push_str(&format!(
            "      *>    MOVE WS-SQL-CURRENT-VALUE TO WS-MY-NAME-FIELD\n"
        ));
        out.push_str(&format!("           PERFORM UNTIL WS-SQL-MORE = 'N'\n"));
        out.push_str(&format!("               MOVE 1 TO WS-SQL-COL-INDEX\n"));
        out.push_str(&format!("               CALL \"COBOL-FETCH-ROW\"\n"));
        out.push_str(&format!(
            "                   USING BY REFERENCE {pfx}-HANDLE\n"
        ));
        out.push_str(&format!(
            "                         BY REFERENCE WS-SQL-COL-INDEX\n"
        ));
        out.push_str(&format!(
            "                         BY REFERENCE WS-SQL-CURRENT-VALUE\n"
        ));
        out.push_str(&format!(
            "                         BY REFERENCE WS-SQL-ERROR\n"
        ));
        out.push_str(&format!(
            "      *>          MOVE WS-SQL-CURRENT-VALUE TO your-field-here\n"
        ));
        out.push_str(&format!("               CONTINUE\n"));
        out.push_str(&format!("               CALL \"COBOL-NEXT-ROW\"\n"));
        out.push_str(&format!(
            "                   USING BY REFERENCE {pfx}-HANDLE\n"
        ));
        out.push_str(&format!(
            "                         BY REFERENCE WS-SQL-MORE\n"
        ));
        out.push_str(&format!("           END-PERFORM.\n"));
        out.push('\n');

        // ── {id}-CLOSE ─────────────────────────────────────────────────────
        out.push_str(&format!("       {close_para}.\n"));
        out.push_str(&format!(
            "      *>  Close the {drv_label} connection for {id}.\n"
        ));
        out.push_str(&format!("           CALL \"COBOL-CLOSE-DB\"\n"));
        out.push_str(&format!(
            "               USING BY REFERENCE {pfx}-HANDLE.\n"
        ));
        out.push('\n');

        // ── user event handler stubs ───────────────────────────────────────
        for para in &[&connect_ok, &query_done, &error_para] {
            out.push_str(&format!("       {para}.\n"));
            out.push_str(&format!("      *>  TODO: add your {para} logic here.\n"));
            out.push_str("           CONTINUE.\n");
            out.push('\n');
        }
    }
}

// ── IndexedFile control stub generator ───────────────────────────────────────

fn write_indexed_file_stubs(out: &mut String, all_controls: &[&Control]) {
    for ctrl in all_controls
        .iter()
        .filter(|c| c.control_type == ControlType::IndexedFile)
    {
        let id = ctrl.id.as_str();
        let file = indexed_control_file_name(ctrl);
        let record = prop_string(ctrl, "RecordName")
            .filter(|s| !s.trim().is_empty())
            .unwrap_or_else(|| format!("{file}-RECORD"));
        let key = prop_string(ctrl, "KeyName")
            .or_else(|| prop_string(ctrl, "CurrentKeyDataItem"))
            .filter(|s| !s.trim().is_empty())
            .unwrap_or_else(|| format!("{record}-KEY"));
        let status_item = prop_string(ctrl, "StatusDataItem")
            .filter(|s| !s.trim().is_empty())
            .unwrap_or_else(|| format!("WS-{}-STATUS", id.to_ascii_uppercase()));
        let open_mode = prop_string(ctrl, "OpenMode").unwrap_or_else(|| "INPUT".into());
        let operator = prop_string(ctrl, "OperatorName").unwrap_or_default();
        let cobol_open_mode = if open_mode.eq_ignore_ascii_case("I-O") {
            "I-O"
        } else {
            "INPUT"
        };

        out.push_str(&format!("       {id}-OPEN.\n"));
        out.push_str(&format!(
            "      *>  Opens indexed file {file} for {cobol_open_mode}.\n"
        ));
        out.push_str(&format!("           IF WS-{id}-IS-OPEN = 0\n"));
        if operator.trim().is_empty() {
            out.push_str(&format!("               OPEN {cobol_open_mode} {file}\n"));
        } else {
            out.push_str(&format!(
                "               OPEN {cobol_open_mode} {file} REGISTERED USER {operator}\n"
            ));
        }
        out.push_str(&format!("               MOVE '00' TO {status_item}\n"));
        out.push_str(&format!("               MOVE 1 TO WS-{id}-IS-OPEN\n"));
        out.push_str(&format!("               MOVE 0 TO WS-{id}-AT-END\n"));
        out.push_str(&format!("               MOVE 0 TO WS-{id}-HAS-RECORD\n"));
        out.push_str("           END-IF.\n\n");

        out.push_str(&format!("       {id}-START.\n"));
        out.push_str(&format!(
            "      *>  Set {key}, then PERFORM {id}-START to position the current pointer.\n"
        ));
        out.push_str(&format!(
            "           START {file} KEY IS GREATER THAN OR EQUAL TO {key}\n"
        ));
        out.push_str(&format!("               INVALID KEY\n"));
        out.push_str(&format!("                   MOVE '23' TO {status_item}\n"));
        out.push_str(&format!(
            "                   MOVE 0 TO WS-{id}-HAS-RECORD\n"
        ));
        out.push_str("               NOT INVALID KEY\n");
        out.push_str(&format!("                   MOVE '00' TO {status_item}\n"));
        out.push_str(&format!("                   MOVE 0 TO WS-{id}-AT-END\n"));
        out.push_str("           END-START.\n\n");

        for (suffix, direction) in [
            ("READ-NEXT", "NEXT"),
            ("READ-PREVIOUS", "PREVIOUS"),
            ("READ-FIRST", "NEXT"),
            ("READ-LAST", "PREVIOUS"),
        ] {
            out.push_str(&format!("       {id}-{suffix}.\n"));
            if suffix == "READ-FIRST" {
                out.push_str(&format!(
                    "      *>  Set {key} to the lowest desired value, position, then read NEXT.\n"
                ));
                out.push_str(&format!(
                    "           START {file} KEY IS GREATER THAN OR EQUAL TO {key}\n"
                ));
                out.push_str("               INVALID KEY CONTINUE\n");
                out.push_str("           END-START\n");
            } else if suffix == "READ-LAST" {
                out.push_str(&format!(
                    "      *>  Set {key} to the highest desired value, position, then read PREVIOUS.\n"
                ));
                out.push_str(&format!(
                    "           START {file} KEY IS LESS THAN OR EQUAL TO {key}\n"
                ));
                out.push_str("               INVALID KEY CONTINUE\n");
                out.push_str("           END-START\n");
            }
            out.push_str(&format!("           READ {file} {direction}\n"));
            out.push_str("               AT END\n");
            out.push_str(&format!("                   MOVE '10' TO {status_item}\n"));
            out.push_str(&format!("                   MOVE 1 TO WS-{id}-AT-END\n"));
            out.push_str(&format!(
                "                   MOVE 0 TO WS-{id}-HAS-RECORD\n"
            ));
            out.push_str("               NOT AT END\n");
            out.push_str(&format!("                   MOVE '00' TO {status_item}\n"));
            out.push_str(&format!("                   MOVE 0 TO WS-{id}-AT-END\n"));
            out.push_str(&format!(
                "                   MOVE 1 TO WS-{id}-HAS-RECORD\n"
            ));
            out.push_str("           END-READ.\n\n");
        }

        out.push_str(&format!("       {id}-READ-INVALID.\n"));
        out.push_str(&format!(
            "      *>  Direct keyed read. Set {key} before calling this paragraph.\n"
        ));
        out.push_str(&format!("           READ {file}\n"));
        out.push_str("               INVALID KEY\n");
        out.push_str(&format!("                   MOVE '23' TO {status_item}\n"));
        out.push_str(&format!(
            "                   MOVE 0 TO WS-{id}-HAS-RECORD\n"
        ));
        out.push_str("               NOT INVALID KEY\n");
        out.push_str(&format!("                   MOVE '00' TO {status_item}\n"));
        out.push_str(&format!(
            "                   MOVE 1 TO WS-{id}-HAS-RECORD\n"
        ));
        out.push_str("           END-READ.\n\n");

        for (suffix, verb) in [
            ("WRITE", "WRITE"),
            ("REWRITE", "REWRITE"),
            ("DELETE", "DELETE"),
        ] {
            out.push_str(&format!("       {id}-{suffix}.\n"));
            out.push_str(&format!(
                "      *>  Requires {file} opened I-O. Data comes from bound/set record fields.\n"
            ));
            if verb == "DELETE" {
                out.push_str(&format!("           DELETE {file}\n"));
            } else {
                out.push_str(&format!("           {verb} {record}\n"));
            }
            out.push_str("               INVALID KEY\n");
            out.push_str(&format!("                   MOVE '23' TO {status_item}\n"));
            out.push_str("               NOT INVALID KEY\n");
            out.push_str(&format!("                   MOVE '00' TO {status_item}\n"));
            out.push_str(&format!("           END-{verb}.\n\n"));
        }

        out.push_str(&format!("       {id}-COMMIT.\n"));
        out.push_str(&format!(
            "      *>  Flushes pending indexed-file changes for {file}.\n"
        ));
        out.push_str(&format!("           CLOSE {file}\n"));
        out.push_str(&format!("           OPEN I-O {file}\n"));
        out.push_str(&format!("           MOVE '00' TO {status_item}.\n\n"));

        out.push_str(&format!("       {id}-ROLLBACK.\n"));
        out.push_str("      *>  Transaction rollback is storage-engine dependent; reopen to discard pending cursor state.\n");
        out.push_str(&format!("           CLOSE {file}\n"));
        out.push_str(&format!("           OPEN {cobol_open_mode} {file}\n"));
        out.push_str(&format!("           MOVE '00' TO {status_item}.\n\n"));

        out.push_str(&format!("       {id}-CLOSE.\n"));
        out.push_str("      *>  No-op when already closed. I-O close commits automatically.\n");
        out.push_str(&format!("           IF WS-{id}-IS-OPEN = 1\n"));
        if cobol_open_mode == "I-O" {
            out.push_str(&format!("               PERFORM {id}-COMMIT\n"));
        }
        out.push_str(&format!("               CLOSE {file}\n"));
        out.push_str(&format!("               MOVE 0 TO WS-{id}-IS-OPEN\n"));
        out.push_str(&format!("               MOVE '00' TO {status_item}\n"));
        out.push_str("           END-IF.\n\n");
    }
}

// ── Chart INVOKE verb paragraph generator ─────────────────────────────────────

fn write_chart_stubs(out: &mut String, all_controls: &[&Control]) {
    let chart_types = [
        ControlType::BarChart,
        ControlType::LineChart,
        ControlType::PieChart,
        ControlType::AreaChart,
        ControlType::ScatterChart,
        ControlType::DonutChart,
    ];
    let charts: Vec<&&Control> = all_controls
        .iter()
        .filter(|c| chart_types.contains(&c.control_type))
        .collect();
    if charts.is_empty() {
        return;
    }

    out.push_str("      *> ── Chart INVOKE verb paragraphs ─────────────────────────────────\n");
    out.push('\n');

    for ctrl in charts {
        let id = &ctrl.id;
        let ws = format!("WS-{}", id);
        let ds = ctrl
            .get_prop("DataSource")
            .map(|v| v.as_str().to_owned())
            .filter(|s| !s.is_empty())
            .unwrap_or_else(|| format!("WS-{}-TABLE", id));
        let cnt = ctrl
            .get_prop("DataCount")
            .map(|v| v.as_str().to_owned())
            .filter(|s| !s.is_empty())
            .unwrap_or_else(|| format!("WS-{}-COUNT", id));

        // ── SET-TABLE ────────────────────────────────────────────────────────
        out.push_str(&format!("       {id}-SET-TABLE.\n"));
        out.push_str(&format!("      *>    Bind a COBOL table to {id}.\n"));
        out.push_str(&format!(
            "      *>    Usage: INVOKE {id} SET-TABLE USING {ds} {cnt}\n"
        ));
        out.push_str(&format!(
            "           MOVE {cnt}        TO {ws}-SELECTED-IDX\n"
        ));
        out.push_str(&format!(
            "           CALL \"COBOL-CHART-SET-TABLE\" USING \"{id}\" {ds} {cnt}\n"
        ));
        out.push_str("           CONTINUE.\n");
        out.push('\n');

        // ── ADD-POINT ────────────────────────────────────────────────────────
        out.push_str(&format!("       {id}-ADD-POINT.\n"));
        out.push_str(&format!(
            "      *>    Append a single data point to {id}.\n"
        ));
        out.push_str(&format!(
            "      *>    Usage: INVOKE {id} ADD-POINT USING WS-LABEL WS-VALUE\n"
        ));
        out.push_str(&format!(
            "           CALL \"COBOL-CHART-ADD-POINT\" USING \"{id}\" {ws}-SELECTED-LBL {ws}-SELECTED-VAL\n"
        ));
        out.push_str("           CONTINUE.\n");
        out.push('\n');

        // ── CLEAR ────────────────────────────────────────────────────────────
        out.push_str(&format!("       {id}-CLEAR.\n"));
        out.push_str(&format!("      *>    Remove all data series from {id}.\n"));
        out.push_str(&format!("      *>    Usage: INVOKE {id} CLEAR\n"));
        out.push_str(&format!(
            "           CALL \"COBOL-CHART-CLEAR\" USING \"{id}\"\n"
        ));
        out.push_str("           CONTINUE.\n");
        out.push('\n');

        // ── REFRESH ──────────────────────────────────────────────────────────
        out.push_str(&format!("       {id}-REFRESH.\n"));
        out.push_str(&format!(
            "      *>    Force {id} to redraw with current data.\n"
        ));
        out.push_str(&format!("      *>    Usage: INVOKE {id} REFRESH\n"));
        out.push_str(&format!(
            "           CALL \"COBOL-CHART-REFRESH\" USING \"{id}\"\n"
        ));
        out.push_str("           CONTINUE.\n");
        out.push('\n');
    }

    // ── Indexed File control fields ───────────────────────────────────────
    for ctrl in all_controls
        .iter()
        .filter(|c| c.control_type == ControlType::IndexedFile)
    {
        let pfx = format!("WS-{}", ctrl.id.to_ascii_uppercase());
        let selected = ctrl
            .get_prop("IndexedFile")
            .map(|v| v.as_str().to_owned())
            .unwrap_or_default();
        let mode = ctrl
            .get_prop("OpenMode")
            .map(|v| v.as_str().to_owned())
            .unwrap_or_else(|| "INPUT".into());
        let strategy = ctrl
            .get_prop("LoadStrategy")
            .map(|v| v.as_str().to_owned())
            .unwrap_or_else(|| "Disk".into());
        let status_item = ctrl
            .get_prop("StatusDataItem")
            .map(|v| v.as_str().to_owned())
            .filter(|s| !s.trim().is_empty())
            .unwrap_or_else(|| format!("{pfx}-STATUS"));

        out.push_str(&format!(
            "      *>── IndexedFile control: {} ─────────────────────────────\n",
            ctrl.id
        ));
        out.push_str(&format!(
            "      *>   Project indexed file: {}\n",
            if selected.trim().is_empty() {
                "<not selected>"
            } else {
                selected.as_str()
            }
        ));
        out.push_str(&format!(
            "       01 {pfx}-OPEN-MODE      PIC X(8)    VALUE '{}'.\n",
            cobol_lit(&mode)
        ));
        out.push_str(&format!(
            "       01 {pfx}-LOAD-STRATEGY  PIC X(8)    VALUE '{}'.\n",
            cobol_lit(&strategy)
        ));
        out.push_str(&format!(
            "       01 {pfx}-IS-OPEN        PIC 9       VALUE 0.\n"
        ));
        out.push_str(&format!(
            "       01 {pfx}-AT-END         PIC 9       VALUE 0.\n"
        ));
        out.push_str(&format!(
            "       01 {pfx}-HAS-RECORD     PIC 9       VALUE 0.\n"
        ));
        out.push_str(&format!(
            "       01 {pfx}-CURRENT-OP     PIC X(16)   VALUE SPACES.\n"
        ));
        out.push_str(&format!(
            "       01 {status_item:<24} PIC X(2)    VALUE '00'.\n"
        ));
        out.push('\n');
    }
}

// ── Nested COBOL-85 program generator ────────────────────────────────────────

/// Emit one nested `PROGRAM-ID ... END PROGRAM` block per event handler.
/// Form-level OnLoad / OnClose come first, then per-control events.
fn write_nested_programs(out: &mut String, form: &Form, all_controls: &[&Control]) {
    let has_any = !form.form_events.is_empty()
        || all_controls.iter().any(|c| !c.events.is_empty())
        || !form.user_procedures.is_empty();
    if !has_any {
        return;
    }

    out.push_str("\n      *> ── Nested event-handler programs (COBOL-85) ─────────────────────\n");
    out.push('\n');

    // Every woven procedure — event handlers included — is `IS COMMON` (spec 009
    // R4) so any procedure is callable from anywhere within the form module (e.g.
    // one handler CALLing another, or a user procedure CALLing a handler).
    for ev in &form.form_events {
        write_nested_program(
            out,
            &ev.paragraph,
            &ev.event,
            &ev.code,
            &format!("Form {} handler", ev.event),
            true,
            None,
        );
    }

    // Per-control events. A control that belongs to a repeating group (array)
    // gets the indexed handler stub — it receives the 1-based array index of the
    // item that fired.
    for ctrl in all_controls {
        let array_member = form
            .array_binding_context_for_member(&ctrl.id)
            .map(|_| ctrl.id.clone());
        for ev in &ctrl.events {
            write_nested_program(
                out,
                &ev.paragraph,
                &ev.event,
                &ev.code,
                &format!("{} {} handler", ctrl.id, ev.event),
                true,
                array_member.as_deref(),
            );
        }
    }

    // User procedures (spec 005) — nested programs callable by name from the
    // event handlers. A handler is a *sibling* contained program, so the
    // procedure must be `IS COMMON` for that CALL to be valid COBOL-85.
    for up in &form.user_procedures {
        if up.name.trim().is_empty() {
            continue;
        }
        write_nested_program(
            out,
            up.name.trim(),
            "",
            &up.code,
            &format!("user procedure {}", up.name.trim()),
            true,
            None,
        );
    }
}

/// Emit a single COBOL-85 nested program for one event handler.
///
/// The developer owns the whole handler body (`ENVIRONMENT DIVISION` …
/// `PROCEDURE DIVISION` + statements), stored in `source`. The generator only
/// adds the `IDENTIFICATION DIVISION` / `PROGRAM-ID` header and the closing
/// `GOBACK` / `END PROGRAM`. An unwritten handler is emitted from the shared
/// [`event_handler_template`] so the generated file always compiles.
///
/// `common` emits `IS COMMON PROGRAM` so the nested program can be CALLed by its
/// siblings (used for user procedures, which handlers call).
fn write_nested_program(
    out: &mut String,
    prog_id: &str,
    event: &str,
    source: &str,
    comment: &str,
    common: bool,
    array_member: Option<&str>,
) {
    let attr = if common { " IS COMMON PROGRAM" } else { "" };
    out.push_str("       IDENTIFICATION DIVISION.\n");
    out.push_str(&format!("       PROGRAM-ID. {}{}.\n", prog_id, attr));
    out.push('\n');

    let trimmed = source.trim();
    let body = if trimmed.is_empty() {
        out.push_str(&format!("      *>    TODO: {}\n", comment));
        match array_member {
            Some(control_id) => {
                cobolt_forms::model::event_handler_template_indexed(event, control_id)
            }
            None => cobolt_forms::model::event_handler_template(event),
        }
    } else {
        source.to_string()
    };
    for line in body.trim_end().lines() {
        out.push_str(line);
        out.push('\n');
    }
    out.push('\n');

    out.push_str("           GOBACK.\n");
    out.push('\n');
    out.push_str(&format!("       END PROGRAM {}.\n", prog_id));
    out.push('\n');
}

fn write_event_loop(out: &mut String, form: &Form) {
    out.push_str("       COBOL-EVENT-LOOP.\n");
    out.push_str("           PERFORM UNTIL COBOL-QUIT = 1\n");
    out.push_str("               CALL \"COBOL-WAIT-EVENT\"\n");
    out.push_str("                   USING COBOL-EVENT-ID COBOL-CONTROL-ID\n");

    let all_controls = collect_all_controls(&form.controls);
    let controls_with_events: Vec<_> = all_controls
        .iter()
        .filter(|c| !c.events.is_empty())
        .collect();

    // Form-level events dispatched through the loop. `onLoad` / `onClose` are
    // CALLed directly from COBOL-MAIN (not via the loop), so they're excluded
    // here; every other bound form event (onShow, onActivate, onResize, …) is
    // dispatched under a WHEN that matches the form's own id.
    let form_loop_events: Vec<_> = form
        .form_events
        .iter()
        .filter(|e| e.event != "onLoad" && e.event != "onClose")
        .collect();

    if controls_with_events.is_empty() && form_loop_events.is_empty() {
        // No events — nothing to dispatch.
        out.push_str("               *> No event handlers defined yet.\n");
        out.push_str("               CONTINUE\n");
    } else {
        out.push_str("               EVALUATE COBOL-CONTROL-ID\n");
        // Form-level events first (COBOL-CONTROL-ID = the form name).
        if !form_loop_events.is_empty() {
            out.push_str(&format!("                   WHEN \"{}\"\n", form.name));
            out.push_str("                       EVALUATE COBOL-EVENT-ID\n");
            for ev in &form_loop_events {
                out.push_str(&format!(
                    "                           WHEN \"{}\"\n",
                    ev.event
                ));
                if matches!(ev.event.as_str(), "onDeactivate" | "onDeactivated") {
                    for ctrl in all_controls.iter().filter(|c| {
                        c.control_type == ControlType::IndexedFile
                            && prop_bool(c, "AutoOpen", false)
                    }) {
                        out.push_str(&format!(
                            "                               PERFORM {}-CLOSE\n",
                            ctrl.id
                        ));
                    }
                }
                out.push_str(&format!(
                    "                               CALL \"{}\"\n",
                    ev.paragraph
                ));
            }
            out.push_str("                       END-EVALUATE\n");
        }
        for ctrl in &controls_with_events {
            out.push_str(&format!("                   WHEN \"{}\"\n", ctrl.id));
            out.push_str("                       EVALUATE COBOL-EVENT-ID\n");
            for ev in &ctrl.events {
                out.push_str(&format!(
                    "                           WHEN \"{}\"\n",
                    ev.event
                ));
                // Dispatch to nested program via CALL (not PERFORM).
                // For repeating-group (array) member controls, pass the index
                // so the handler's CONTROL-ARRAY-INDEX linkage item is populated.
                if form.array_binding_context_for_member(&ctrl.id).is_some() {
                    out.push_str(&format!(
                        "                               CALL \"{}\" USING CONTROL-ARRAY-INDEX\n",
                        ev.paragraph
                    ));
                } else {
                    out.push_str(&format!(
                        "                               CALL \"{}\"\n",
                        ev.paragraph
                    ));
                }
            }
            out.push_str("                       END-EVALUATE\n");
        }
        out.push_str("               END-EVALUATE\n");
    }

    out.push_str("           END-PERFORM.\n");
    out.push('\n');
}

fn write_stub_paragraph(out: &mut String, name: &str, comment: &str) {
    out.push_str(&format!("       {}.\n", name));
    out.push_str(&format!("      *>    TODO: {}\n", comment));
    out.push_str("           CONTINUE.\n");
    out.push('\n');
}

// ── Helpers ───────────────────────────────────────────────────────────────────

/// Flatten a nested control tree into a pre-order Vec.
fn collect_all_controls(controls: &[Control]) -> Vec<&Control> {
    let mut result = Vec::new();
    for ctrl in controls {
        collect_rec(ctrl, &mut result);
    }
    result
}

fn collect_rec<'a>(ctrl: &'a Control, out: &mut Vec<&'a Control>) {
    out.push(ctrl);
    for child in &ctrl.children {
        collect_rec(child, out);
    }
}

fn prop_string(ctrl: &Control, key: &str) -> Option<String> {
    ctrl.get_prop(key).map(|v| v.as_str().to_owned())
}

fn prop_bool(ctrl: &Control, key: &str, fallback: bool) -> bool {
    ctrl.get_prop(key).map(|v| v.as_bool()).unwrap_or(fallback)
}

fn cobol_lit(s: &str) -> String {
    s.replace('\'', "''")
}

fn indexed_control_file_name(ctrl: &Control) -> String {
    let selected = prop_string(ctrl, "IndexedFile").unwrap_or_default();
    let stem = selected
        .rsplit(|ch| ch == '/' || ch == '\\')
        .next()
        .unwrap_or(selected.as_str())
        .rsplit_once('.')
        .map(|(left, _)| left)
        .unwrap_or_else(|| selected.as_str());
    let source = if stem.trim().is_empty() {
        ctrl.id.as_str()
    } else {
        stem
    };
    let mut out = String::new();
    for ch in source.chars() {
        if ch.is_ascii_alphanumeric() {
            out.push(ch.to_ascii_uppercase());
        } else if ch == '-' || ch == '_' || ch.is_whitespace() {
            if !out.ends_with('-') {
                out.push('-');
            }
        }
    }
    let out = out.trim_matches('-').to_owned();
    if out.is_empty() {
        ctrl.id.to_ascii_uppercase()
    } else {
        out
    }
}

/// Which property key holds the display text for a given control type.
fn caption_prop_key(ct: &ControlType) -> &'static str {
    match ct {
        ControlType::Label => "Caption",
        ControlType::Button => "Caption",
        ControlType::CheckBox => "Caption",
        ControlType::RadioButton => "Caption",
        ControlType::GroupBox => "Caption",
        ControlType::TextBox => "Text",
        ControlType::ComboBox => "Text",
        ControlType::ListBox => "Text",
        _ => "Caption",
    }
}

// ── Tests ─────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use cobolt_forms::{
        BindingDataType, BindingField, BindingSourceDescriptor, BindingTargetDescriptor,
        BindingTargetPath, Control, ControlType, DataBindingDef, EventBinding, FieldMapping, Form,
        PropValue,
    };

    fn make_form() -> Form {
        let mut form = Form::new("MAIN-FORM", "Test", 800, 600);

        let mut btn = Control::new("BTN-OK", ControlType::Button, 10, 10);
        btn.events
            .push(EventBinding::for_control("BTN-OK", "onClick"));
        form.controls.push(btn);

        form
    }

    #[test]
    fn generate_contains_program_id() {
        let src = generate(&make_form());
        assert!(src.contains("PROGRAM-ID. MAIN-FORM."), "missing PROGRAM-ID");
    }

    #[test]
    fn generate_indexed_file_control_facade() {
        let mut form = Form::new("CUSTOMER-FORM", "Customers", 800, 600);
        let mut idx = Control::new("CustomerFile", ControlType::IndexedFile, 0, 0);
        idx.set_prop(
            "IndexedFile",
            PropValue::String("indexed/customers.cidx".into()),
        );
        idx.set_prop("OpenMode", PropValue::String("I-O".into()));
        idx.set_prop("AutoOpen", PropValue::Bool(true));
        idx.set_prop("RecordName", PropValue::String("CUSTOMER-REC".into()));
        idx.set_prop("KeyName", PropValue::String("CUSTOMER-ID".into()));
        form.controls.push(idx);

        let src = generate(&form);

        assert!(src.contains("PERFORM CustomerFile-OPEN"));
        assert!(src.contains("PERFORM CustomerFile-CLOSE"));
        assert!(src.contains("OPEN I-O CUSTOMERS"));
        assert!(src.contains("CustomerFile-START."));
        assert!(src.contains("CustomerFile-READ-NEXT."));
        assert!(src.contains("CustomerFile-READ-PREVIOUS."));
        assert!(src.contains("CustomerFile-WRITE."));
        assert!(src.contains("WRITE CUSTOMER-REC"));
        assert!(src.contains("CustomerFile-COMMIT."));
    }

    #[test]
    fn generate_weaves_cobol_structure_005() {
        use cobolt_forms::model::UserProcedure;
        let mut form = make_form();
        form.cobol_structure.special_names = "       DECIMAL-POINT IS COMMA.".into();
        form.cobol_structure.repository = "       FUNCTION ALL INTRINSIC.".into();
        form.cobol_structure.file_control = "           SELECT F ASSIGN TO \"f.dat\".".into();
        form.cobol_structure.file_section = "       FD  F.\n       01 F-REC PIC X(80).".into();
        form.user_procedures = vec![UserProcedure {
            name: "RECALC-TOTAL".into(),
            code: "       ENVIRONMENT DIVISION.\n       PROCEDURE DIVISION.\n           CONTINUE."
                .into(),
        }];
        let src = generate(&form);

        assert!(src.contains("CONFIGURATION SECTION."));
        assert!(src.contains("SPECIAL-NAMES.") && src.contains("DECIMAL-POINT IS COMMA."));
        assert!(src.contains("REPOSITORY.") && src.contains("FUNCTION ALL INTRINSIC."));
        assert!(src.contains("INPUT-OUTPUT SECTION.") && src.contains("FILE-CONTROL."));
        assert!(src.contains("SELECT F ASSIGN"));
        // FILE SECTION must come before WORKING-STORAGE SECTION.
        let fs = src.find("FILE SECTION.").expect("no FILE SECTION");
        let ws = src
            .find("WORKING-STORAGE SECTION.")
            .expect("no WORKING-STORAGE");
        assert!(fs < ws, "FILE SECTION must precede WORKING-STORAGE");
        // User procedure emitted as a nested program, IS COMMON so the event
        // handlers (sibling contained programs) may CALL it (spec 005 T6).
        assert!(src.contains("PROGRAM-ID. RECALC-TOTAL IS COMMON PROGRAM."));
        assert!(src.contains("END PROGRAM RECALC-TOTAL."));
        // Banner still present.
        assert!(src.contains("generated automatically by PowerRustCOBOL"));
    }

    #[test]
    fn generate_all_procedures_are_common_009() {
        // Spec 009 R4: every woven procedure — event handlers AND user procedures
        // — is `IS COMMON` so any procedure is callable from anywhere in the form.
        use cobolt_forms::model::UserProcedure;
        let mut form = make_form(); // has BTN-OK onClick handler
        form.user_procedures = vec![UserProcedure {
            name: "RECALC-TOTAL".into(),
            code: "       ENVIRONMENT DIVISION.\n       PROCEDURE DIVISION.\n           CONTINUE."
                .into(),
        }];
        let src = generate(&form);

        // The control event handler is now IS COMMON.
        assert!(
            src.contains("PROGRAM-ID. BTN-OK--ONCLICK IS COMMON PROGRAM."),
            "event handler must be IS COMMON (009 R4):\n{src}"
        );
        // Form-level OnLoad/OnClose handlers too.
        assert!(
            src.contains("IS COMMON PROGRAM.") && src.matches("IS COMMON PROGRAM.").count() >= 3,
            "all woven procedures (form events + control event + user proc) must be IS COMMON"
        );
        // And the user procedure (already COMMON pre-009) stays COMMON.
        assert!(src.contains("PROGRAM-ID. RECALC-TOTAL IS COMMON PROGRAM."));
    }

    #[test]
    fn generate_starts_with_developer_header() {
        let src = generate(&make_form());
        // GOLDEN RULE: a developer banner precedes IDENTIFICATION DIVISION.
        assert!(src.starts_with("      *>"), "header must be first");
        assert!(
            src.contains("generated automatically by PowerRustCOBOL RAD"),
            "missing generated-by line"
        );
        assert!(
            src.contains("DO NOT MODIFY IT DIRECTLY"),
            "missing do-not-modify warning"
        );
        assert!(src.contains("Apache 2.0 License"), "missing license line");
        // The banner sits above the program proper.
        let hdr = src.find("*>").unwrap();
        let id = src.find("IDENTIFICATION DIVISION.").unwrap();
        assert!(hdr < id, "header must come before IDENTIFICATION DIVISION");
    }

    #[test]
    fn generate_contains_event_loop() {
        let src = generate(&make_form());
        assert!(
            src.contains("COBOL-EVENT-LOOP"),
            "missing event loop paragraph"
        );
        assert!(src.contains("WHEN \"BTN-OK\""), "missing control WHEN");
        assert!(src.contains("WHEN \"onClick\""), "missing event WHEN");
        // v1.0.0: dispatch via CALL to nested program (double-hyphen name)
        assert!(
            src.contains("CALL \"BTN-OK--ONCLICK\""),
            "missing nested CALL dispatch"
        );
    }

    #[test]
    fn generate_contains_data_group() {
        let src = generate(&make_form());
        assert!(src.contains("01 WS-BTN-OK."), "missing WS group for BTN-OK");
    }

    #[test]
    fn generate_contains_nested_program() {
        let src = generate(&make_form());
        // v1.0.0: event handlers are nested COBOL-85 programs.
        // Spec 009 R4: each is `IS COMMON PROGRAM` (callable from anywhere in the form).
        assert!(
            src.contains("PROGRAM-ID. BTN-OK--ONCLICK IS COMMON PROGRAM."),
            "missing nested program ID"
        );
        assert!(
            src.contains("END PROGRAM BTN-OK--ONCLICK."),
            "missing END PROGRAM for handler"
        );
        assert!(src.contains("GOBACK."), "missing GOBACK in nested program");
        assert!(
            src.contains("END PROGRAM MAIN-FORM."),
            "missing outer END PROGRAM"
        );
    }

    #[test]
    fn form_level_events_dispatch_through_the_loop() {
        // A bound form-level event (onResize) must be dispatched under a WHEN
        // matching the form's own id — not just generated as a nested program.
        let mut form = Form::new("MAIN-FORM", "Test", 800, 600);
        form.form_events
            .push(EventBinding::for_control("MAIN-FORM", "onResize"));
        let src = generate(&form);
        assert!(
            src.contains("WHEN \"MAIN-FORM\""),
            "event loop missing a WHEN for the form id"
        );
        assert!(
            src.contains("WHEN \"onResize\""),
            "missing onResize event WHEN"
        );
        assert!(
            src.contains("CALL \"MAIN-FORM--ONRESIZE\""),
            "onResize not dispatched to its nested program"
        );
    }

    #[test]
    fn generate_contains_form_events_nested() {
        let src = generate(&make_form());
        // Form events (OnLoad / OnClose) also become nested programs
        // Paragraph names come from `derive_paragraph_name`, which uppercases the
        // event name without inserting separators: "OnLoad" → "ONLOAD".
        // Spec 009 R4: form-event handlers are `IS COMMON PROGRAM` too.
        assert!(
            src.contains("PROGRAM-ID. MAIN-FORM--ONLOAD IS COMMON PROGRAM."),
            "missing OnLoad nested program"
        );
        assert!(
            src.contains("PROGRAM-ID. MAIN-FORM--ONCLOSE IS COMMON PROGRAM."),
            "missing OnClose nested program"
        );
    }

    #[test]
    fn generate_calls_on_load_nested() {
        let src = generate(&make_form());
        // Form::new() pre-populates form_events with OnLoad; COBOL-MAIN must CALL it.
        assert!(
            src.contains("CALL \"MAIN-FORM--ONLOAD\""),
            "missing OnLoad CALL in COBOL-MAIN"
        );
    }

    /// `regenerate` is now a clean alias for `generate` — all event code lives in the
    /// form model, so the existing .cbl content is irrelevant and ignored.
    #[test]
    fn regenerate_equals_generate() {
        let form = make_form();
        // Pass a non-empty "existing" source — it must be completely ignored.
        let existing = "       STALE-PARA.\n           CONTINUE.\n";
        assert_eq!(
            regenerate(&form, existing),
            generate(&form),
            "regenerate must return the same output as generate regardless of existing_source"
        );
    }

    /// Event-handler source stored in the model is emitted into the nested
    /// program body — including its own WORKING-STORAGE declarations.
    #[test]
    fn generate_emits_event_handler_code() {
        let mut form = Form::new("MAIN-FORM", "Test", 800, 600);
        let mut btn = Control::new("BTN-OK", ControlType::Button, 10, 10);
        let mut ev = EventBinding::for_control("BTN-OK", "onClick");
        ev.code = "\
       ENVIRONMENT DIVISION.\n\
       DATA DIVISION.\n\
       WORKING-STORAGE SECTION.\n\
       01 WS-LOCAL-FLAG  PIC 9 VALUE 0.\n\
       LINKAGE SECTION.\n\
\n\
       PROCEDURE DIVISION.\n\
           MOVE 1 TO COBOL-QUIT."
            .into();
        btn.events.push(ev);
        form.controls.push(btn);

        let src = generate(&form);
        assert!(
            src.contains("MOVE 1 TO COBOL-QUIT"),
            "handler statements must appear in the nested program body"
        );
        assert!(
            src.contains("WS-LOCAL-FLAG"),
            "handler-local WORKING-STORAGE must appear in the nested program"
        );
    }

    /// An unwritten handler is emitted from the shared template (it still
    /// compiles): LINKAGE SECTION present, PROCEDURE DIVISION + CONTINUE.
    #[test]
    fn generate_emits_template_stub_for_empty_handler() {
        let mut form = Form::new("MAIN-FORM", "Test", 800, 600);
        let mut btn = Control::new("BTN-OK", ControlType::Button, 10, 10);
        btn.events
            .push(EventBinding::for_control("BTN-OK", "onClick")); // no code
        form.controls.push(btn);

        let src = generate(&form);
        assert!(
            src.contains("LINKAGE SECTION."),
            "the stub handler must include a LINKAGE SECTION"
        );
        assert!(
            src.contains("PROCEDURE DIVISION."),
            "the stub handler must include a PROCEDURE DIVISION"
        );
    }

    /// A control that belongs to a repeating group (array) gets the indexed
    /// handler stub: it receives the fired item's 1-based array index.
    #[test]
    fn array_member_handler_stub_receives_array_index() {
        let mut form = Form::new("MAIN-FORM", "Test", 800, 600);
        let mut group = Control::new("CARD", ControlType::GroupBox, 0, 0);
        group.set_prop("IsRepeatingGroup", PropValue::Bool(true));
        let mut btn = Control::new("Button-1", ControlType::Button, 10, 10);
        btn.parent = Some("CARD".into());
        btn.events
            .push(EventBinding::for_control("Button-1", "onClick")); // no code
        form.controls.push(group);
        form.controls.push(btn);

        let src = generate(&form);
        assert!(
            src.contains("01 CONTROL-ARRAY-INDEX              PIC S9(4) COMP-5."),
            "array-member handler must declare CONTROL-ARRAY-INDEX:\n{src}"
        );
        assert!(
            src.contains("PROCEDURE DIVISION USING CONTROL-ARRAY-INDEX."),
            "array-member handler must receive the index via USING:\n{src}"
        );
        assert!(
            src.contains("Button-1(CONTROL-ARRAY-INDEX)::BackgroundColor"),
            "stub should hint indexed member access:\n{src}"
        );

        // A non-array control keeps the plain stub (no index parameter).
        let mut plain = Form::new("MAIN-FORM", "Test", 800, 600);
        let mut btn2 = Control::new("BTN-OK", ControlType::Button, 10, 10);
        btn2.events
            .push(EventBinding::for_control("BTN-OK", "onClick"));
        plain.controls.push(btn2);
        let plain_src = generate(&plain);
        assert!(!plain_src.contains("CONTROL-ARRAY-INDEX"));
    }

    fn binding_fields() -> Vec<BindingField> {
        vec![
            BindingField::new("ID", BindingDataType::Integer).key(),
            BindingField::new("NAME", BindingDataType::Text).required(),
            BindingField::new("AMOUNT", BindingDataType::Decimal).required(),
        ]
    }

    fn data_binding_fixture_form() -> Form {
        let mut form = Form::new("BIND-FORM", "Bindings", 800, 600);
        form.add_control(Control::new("GRID-1", ControlType::DataGrid, 0, 0));
        form.add_control(Control::new("CHART-1", ControlType::BarChart, 0, 120));
        form.add_control(Control::new("COMBO-1", ControlType::ComboBox, 0, 240));
        form.add_control(Control::new("LIST-1", ControlType::ListBox, 0, 300));
        let mut group = Control::new("ROWS", ControlType::GroupBox, 0, 360);
        group.set_prop("IsRepeatingGroup", PropValue::Bool(true));
        group.set_prop("ArrayName", PropValue::String("CUSTOMERS".into()));
        let mut name = Control::new("NAME", ControlType::TextBox, 10, 390);
        name.parent = Some("ROWS".into());
        form.add_control(group);
        form.add_control(name);

        let fields = binding_fields();
        form.data_bindings.push(
            DataBindingDef::new(
                "BIND-IDX-GRID",
                "Indexed Grid",
                BindingSourceDescriptor::IndexedFile {
                    definition_path: "data/customers.cidx".into(),
                    record_name: "CUSTOMER-REC".into(),
                    fields: fields.clone(),
                    key_field: Some("ID".into()),
                    writable: true,
                },
                BindingTargetDescriptor::DataGrid {
                    control_id: "GRID-1".into(),
                },
            )
            .with_mappings(vec![
                FieldMapping::new(
                    "ID",
                    BindingTargetPath::GridColumn {
                        control_id: "GRID-1".into(),
                        column_id: "ID".into(),
                    },
                ),
                FieldMapping::new(
                    "NAME",
                    BindingTargetPath::GridColumn {
                        control_id: "GRID-1".into(),
                        column_id: "NAME".into(),
                    },
                ),
            ]),
        );
        form.data_bindings.push(
            DataBindingDef::new(
                "BIND-SQL-ARRAY",
                "SQL Array",
                BindingSourceDescriptor::Sql {
                    source_control_id: "SQL-1".into(),
                    query_name: "CUSTOMERS".into(),
                    result_set_name: "CUSTOMER-ROWS".into(),
                    fields: fields.clone(),
                    key_fields: vec!["ID".into()],
                    writable: true,
                },
                BindingTargetDescriptor::ControlArray {
                    array_id: "CUSTOMERS".into(),
                    member_control_ids: vec!["NAME".into()],
                },
            )
            .with_mappings(vec![FieldMapping::new(
                "NAME",
                BindingTargetPath::ControlProperty {
                    array_id: "CUSTOMERS".into(),
                    control_id: "NAME".into(),
                    property_name: "Text".into(),
                },
            )]),
        );
        form.data_bindings.push(
            DataBindingDef::new(
                "BIND-TABLE-CHART",
                "Table Chart",
                BindingSourceDescriptor::CobolTable {
                    table_name: "CUSTOMER-TABLE".into(),
                    occurs_item: "CUSTOMER-ROW".into(),
                    fields: fields.clone(),
                    key_fields: vec!["ID".into()],
                    writable: true,
                },
                BindingTargetDescriptor::Chart {
                    control_id: "CHART-1".into(),
                    chart_kind: cobolt_forms::BindingChartKind::Bar,
                },
            )
            .with_mappings(vec![
                FieldMapping::new(
                    "NAME",
                    BindingTargetPath::ChartCategory {
                        control_id: "CHART-1".into(),
                    },
                ),
                FieldMapping::new(
                    "AMOUNT",
                    BindingTargetPath::ChartValueSeries {
                        control_id: "CHART-1".into(),
                        series_id: "AMOUNT".into(),
                    },
                ),
            ]),
        );
        form.data_bindings.push(DataBindingDef::new(
            "BIND-REST-LIST",
            "REST List",
            BindingSourceDescriptor::RestApi {
                source_control_id: "REST-1".into(),
                endpoint_name: "GET-CUSTOMERS".into(),
                response_data_item: "REST-RESPONSE".into(),
                fields: fields.clone(),
                update: None,
            },
            BindingTargetDescriptor::ListBox {
                control_id: "LIST-1".into(),
            },
        ));
        form.data_bindings.push(
            DataBindingDef::new(
                "BIND-AGENT-COMBO",
                "Agent Combo",
                BindingSourceDescriptor::AgentAi {
                    source_control_id: "AGENT-1".into(),
                    output_name: "CUSTOMER-CHOICES".into(),
                    fields,
                    update: None,
                },
                BindingTargetDescriptor::ComboBox {
                    control_id: "COMBO-1".into(),
                },
            )
            .with_mappings(vec![
                FieldMapping::new(
                    "NAME",
                    BindingTargetPath::ListDisplayItem {
                        control_id: "COMBO-1".into(),
                    },
                ),
                FieldMapping::new(
                    "ID",
                    BindingTargetPath::ListValue {
                        control_id: "COMBO-1".into(),
                    },
                ),
            ]),
        );
        form
    }

    #[test]
    fn data_binding_codegen_emits_deterministic_runtime_sections() {
        let src = generate(&data_binding_fixture_form());
        assert!(src.contains("COBOL-DATA-BINDINGS-LOAD."));
        assert!(src.contains("COBOL-DATA-BINDINGS-POPULATE."));
        assert!(src.contains("COBOL-DATA-BINDINGS-MARK-CLEAN."));
        assert!(src.contains("COBOL-DATA-BINDINGS-UPDATE."));
        assert!(src.contains("CALL \"COBOL-BINDING-LOAD\" USING \"BIND-IDX-GRID\""));
        assert!(src.contains("IndexedFile:CUSTOMER-REC"));
        assert!(src.contains("SQL:CUSTOMER-ROWS"));
        assert!(src.contains("COBOLTable:CUSTOMER-TABLE"));
        assert!(src.contains("REST:GET-CUSTOMERS"));
        assert!(src.contains("AgentAI:CUSTOMER-CHOICES"));
        assert!(src.contains("NAME -> GRID-1.NAME"));
        assert!(src.contains("NAME -> CHART-1.Category"));
        assert!(src.contains("NAME -> NAME.Text"));
        assert!(src.contains("NAME -> COMBO-1.Display"));
    }

    #[test]
    fn data_binding_codegen_is_stable_across_runs() {
        let form = data_binding_fixture_form();
        assert_eq!(generate(&form), generate(&form));
    }

    #[test]
    fn data_binding_codegen_seeds_datagrid_refresh_identity_for_cobol_tables() {
        let mut form = Form::new("BIND-FORM", "Bindings", 800, 600);
        form.add_control(Control::new("GRID-1", ControlType::DataGrid, 0, 0));
        form.data_bindings.push(DataBindingDef::new(
            "BIND-TABLE-GRID",
            "Table Grid",
            BindingSourceDescriptor::CobolTable {
                table_name: "CUSTOMER-TABLE".into(),
                occurs_item: "CUSTOMER-ROW".into(),
                fields: binding_fields(),
                key_fields: vec!["ID".into()],
                writable: true,
            },
            BindingTargetDescriptor::DataGrid {
                control_id: "GRID-1".into(),
            },
        ));

        let src = generate(&form);

        assert!(src.contains(
            "INVOKE GRID-1 'SetProperty' USING BY CONTENT \"_BindingKind\" BY CONTENT \"CobolTable\""
        ));
        assert!(src.contains(
            "INVOKE GRID-1 'SetProperty' USING BY CONTENT \"_BindingFields\" BY CONTENT \"ID,NAME,AMOUNT\""
        ));
    }

    #[test]
    fn datagrid_csv_export_codegen_uses_button_mode_and_order_comment() {
        let mut form = Form::new("CSV-FORM", "CSV", 800, 600);
        let mut grid = Control::new("GRID-1", ControlType::DataGrid, 0, 0);
        grid.set_prop("ExportCSV", PropValue::Bool(false));
        grid.set_prop("ShowCSVExportButton", PropValue::Bool(true));
        grid.set_prop("CSVExportMode", PropValue::String("All".into()));
        grid.set_prop("CSVDelimiter", PropValue::String(";".into()));
        form.add_control(grid);

        let src = generate(&form);

        assert!(src.contains("DataGrid GRID-1 CSV export"));
        assert!(src.contains("Delimiter: \";\". Mode: All."));
        assert!(src.contains("Column order and filtered/all rows follow the DataGrid settings."));
        assert!(src.contains("INVOKE GRID-1 'ExportCSV'"));
    }

    #[test]
    fn data_binding_e2e_generates_all_source_and_target_families() {
        let src = generate(&data_binding_fixture_form());
        for needle in [
            "This code was generated automatically by PowerRustCOBOL RAD.",
            "IndexedFile:CUSTOMER-REC",
            "SQL:CUSTOMER-ROWS",
            "COBOLTable:CUSTOMER-TABLE",
            "REST:GET-CUSTOMERS",
            "AgentAI:CUSTOMER-CHOICES",
            "DataGrid:GRID-1",
            "Chart:CHART-1",
            "ComboBox:COMBO-1",
            "ListBox:LIST-1",
            "ControlArray:CUSTOMERS",
            "COBOL-DATA-BINDINGS-UPDATE.",
        ] {
            assert!(src.contains(needle), "missing {needle}\n{src}");
        }
    }
}
